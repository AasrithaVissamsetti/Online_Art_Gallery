import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/navbar';
import Hero from './components/hero';
import Footer from './components/footer';
import CustomerLogin from './components/Custlogin';
import CustomerSignUp from './components/CustSignup';
import CustomerHome from './components/CustHome';
import ViewArtist from './components/viewArtists';
import ViewArtworks from './components/viewArtworks';
import UserProfile from './components/Profile';
import CuratorSignUp from './components/CuratorSignup';
import AboutUs from './components/Aboutus';
import ContactUs from './components/Contactus';
import CuratorLogin from './components/CuratorLogin';


function App() {
  return (
    <Router>
      <div className="App">
        <Navbar />
        <Routes>
        <Route path="/" element={<Hero />} />
        <Route path="/Custlogin" element={<CustomerLogin/>}/>
        <Route path="/CustSignup" element={<CustomerSignUp/>}/>
        <Route path="/CustHome" element={<CustomerHome/>}/>
        <Route path="/viewArtists" element={<ViewArtist/>}/>
        <Route path="/viewArtworks" element={<ViewArtworks/>}/>
        <Route path="/Profile" element={<UserProfile/>}/>
        <Route path="/CuratorSignup" element={<CuratorSignUp/>}/>
        <Route path="/Aboutus" element = {<AboutUs/>}/>
        <Route path="/Contactus" element={<ContactUs/>}/>
        <Route path="/CuratorLogin" element={<CuratorLogin/>}/>
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;